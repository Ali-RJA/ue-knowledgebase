# Player Character Architecture
> The foundation class that represents the player in the game world — 
> handling physical presence, component composition, and integration with all gameplay systems.

---

## 1. System Overview

The Player Character system solves the fundamental problem of representing the player as a physical entity in the game world. It serves as the central hub that connects input, animation, combat, abilities, and movement into a cohesive playable experience.

In UE5, we inherit from `ACharacter` because it provides built-in support for bipedal humanoid movement, including walking, jumping, crouching, and the `CharacterMovementComponent` with full networking support. This is ideal for a melee combat game where responsive, grounded movement is critical.

For Hattin specifically, our player character must support: sword combat with parrying and dodging, integration with the Gameplay Ability System for special moves, equipment changes (weapons, armor), and seamless animation-driven gameplay where montages control combat timing.

---

## 2. Core Architecture Diagram

### 2.1 UE5 Class Inheritance Hierarchy

```mermaid
flowchart TD
    subgraph "UE5 Foundation Layer"
        UObject["UObject<br/><i>Base engine object</i>"]
        AActor["AActor<br/><i>Placeable world object</i>"]
        APawn["APawn<br/><i>Possessable by Controller</i>"]
        ACharacter["ACharacter<br/><i>Bipedal movement + capsule</i>"]
    end
    
    subgraph "Hattin Game Layer"
        HattinCharBase["AHattinCharacterBase<br/><i>Shared player/enemy base</i>"]
        HattinPlayer["AHattinPlayerCharacter<br/><i>Player-specific features</i>"]
        HattinEnemy["AHattinEnemyCharacter<br/><i>Enemy-specific features</i>"]
    end
    
    UObject --> AActor --> APawn --> ACharacter
    ACharacter --> HattinCharBase
    HattinCharBase --> HattinPlayer
    HattinCharBase --> HattinEnemy
    
    style UObject fill:#1a365d,stroke:#2c5282,color:#fff
    style AActor fill:#1a365d,stroke:#2c5282,color:#fff
    style APawn fill:#1a365d,stroke:#2c5282,color:#fff
    style ACharacter fill:#1a365d,stroke:#2c5282,color:#fff
    style HattinCharBase fill:#22543d,stroke:#276749,color:#fff
    style HattinPlayer fill:#22543d,stroke:#276749,color:#fff
    style HattinEnemy fill:#22543d,stroke:#276749,color:#fff
```

### 2.2 Component Composition Architecture

```mermaid
flowchart TD
    subgraph Character["AHattinPlayerCharacter"]
        subgraph Inherited["Inherited from ACharacter"]
            Capsule["UCapsuleComponent<br/>(Root)"]
            Mesh["USkeletalMeshComponent<br/>(CharacterMesh0)"]
            CMC["UCharacterMovementComponent"]
        end
        
        subgraph SceneComponents["Scene Components (Transform)"]
            SpringArm["USpringArmComponent<br/>(CameraBoom)"]
            Camera["UCameraComponent<br/>(FollowCamera)"]
            WeaponSocket["USceneComponent<br/>(WeaponAttach)"]
        end
        
        subgraph ActorComponents["Actor Components (Logic)"]
            Combat["UHattinCombatComponent"]
            Equipment["UHattinEquipmentComponent"]
            InputBuffer["UHattinInputBufferComponent"]
            Targeting["UHattinTargetingComponent"]
        end
        
        subgraph GASComponents["GAS Integration"]
            ASC["UAbilitySystemComponent"]
            Attributes["UHattinAttributeSet"]
        end
    end
    
    Capsule --> Mesh
    Capsule --> SpringArm
    SpringArm --> Camera
    Mesh --> WeaponSocket
    
    style Capsule fill:#1a365d,stroke:#2c5282,color:#fff
    style Mesh fill:#1a365d,stroke:#2c5282,color:#fff
    style CMC fill:#1a365d,stroke:#2c5282,color:#fff
    style SpringArm fill:#22543d,stroke:#276749,color:#fff
    style Camera fill:#22543d,stroke:#276749,color:#fff
    style WeaponSocket fill:#22543d,stroke:#276749,color:#fff
    style Combat fill:#22543d,stroke:#276749,color:#fff
    style Equipment fill:#22543d,stroke:#276749,color:#fff
    style InputBuffer fill:#22543d,stroke:#276749,color:#fff
    style Targeting fill:#22543d,stroke:#276749,color:#fff
    style ASC fill:#44337a,stroke:#553c9a,color:#fff
    style Attributes fill:#44337a,stroke:#553c9a,color:#fff
```

### 2.3 Initialization Flow (Actor Lifecycle)

```mermaid
sequenceDiagram
    participant World as UWorld
    participant Char as AHattinPlayerCharacter
    participant Comps as Components
    participant ASC as AbilitySystemComponent
    participant Controller as AHattinPlayerController
    
    Note over World,Controller: Spawn Phase
    World->>Char: SpawnActor()
    Char->>Char: Constructor()<br/>CreateDefaultSubobject() for all components
    Char->>Comps: Components created but NOT initialized
    
    Note over World,Controller: Initialization Phase
    Char->>Char: PostInitializeComponents()
    Comps->>Comps: InitializeComponent() called on each
    Char->>Char: Cache component references
    
    Note over World,Controller: Possession Phase
    Controller->>Char: PossessedBy(Controller)
    Char->>ASC: InitAbilityActorInfo(Owner, Avatar)
    Char->>ASC: GiveAbility() for default abilities
    Char->>ASC: ApplyGameplayEffect() for initial attributes
    
    Note over World,Controller: Gameplay Phase
    Char->>Char: BeginPlay()
    Char->>Comps: Start gameplay logic
```

### 2.4 GAS Owner vs Avatar Pattern

```mermaid
flowchart LR
    subgraph "Simple Setup (AI Enemies)"
        Enemy["AHattinEnemyCharacter"]
        EnemyASC["ASC"]
        Enemy -->|"Owner = Avatar"| EnemyASC
    end
    
    subgraph "Persistent Setup (Player)"
        PS["AHattinPlayerState"]
        PlayerASC["ASC"]
        PlayerChar["AHattinPlayerCharacter"]
        
        PS -->|"Owner"| PlayerASC
        PlayerChar -->|"Avatar"| PlayerASC
    end
    
    Note1["AI: ASC on Character<br/>Destroyed on death"]
    Note2["Player: ASC on PlayerState<br/>Persists across respawns"]
    
    style Enemy fill:#22543d,stroke:#276749,color:#fff
    style EnemyASC fill:#44337a,stroke:#553c9a,color:#fff
    style PS fill:#22543d,stroke:#276749,color:#fff
    style PlayerASC fill:#44337a,stroke:#553c9a,color:#fff
    style PlayerChar fill:#22543d,stroke:#276749,color:#fff
```

---

## 3. Component Specifications

### 3.1 AHattinCharacterBase

**UE Base**: `ACharacter` | **Your Class**: `AHattinCharacterBase`

**Purpose**: Shared functionality between player and enemy characters (combat interface, damage handling, death)

```cpp
UCLASS(Abstract)
class HATTIN_API AHattinCharacterBase : public ACharacter, public IAbilitySystemInterface
{
    GENERATED_BODY()
    
public:
    AHattinCharacterBase();
    
    // IAbilitySystemInterface
    virtual UAbilitySystemComponent* GetAbilitySystemComponent() const override;
    
    // Combat Interface
    UFUNCTION(BlueprintCallable, Category = "Combat")
    virtual bool CanBeHit() const;
    
    UFUNCTION(BlueprintCallable, Category = "Combat")
    virtual void OnHitReceived(const FHattinHitResult& HitResult);
    
    UFUNCTION(BlueprintCallable, Category = "Combat")
    virtual void OnDeath();
    
protected:
    // Components - created in derived classes or here if shared
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Combat")
    TObjectPtr<UHattinCombatComponent> CombatComponent;
    
    // Weak reference to ASC (actual ASC may be on PlayerState or this actor)
    UPROPERTY()
    TWeakObjectPtr<UAbilitySystemComponent> AbilitySystemComponent;
    
    UPROPERTY()
    TObjectPtr<UHattinAttributeSet> AttributeSet;
    
    // Cached AnimInstance for performance
    UPROPERTY()
    TWeakObjectPtr<UHattinAnimInstance> AnimInstance;
    
    virtual void PostInitializeComponents() override;
    virtual void BeginPlay() override;
};
```

### 3.2 AHattinPlayerCharacter

**UE Base**: `AHattinCharacterBase` | **Your Class**: `AHattinPlayerCharacter`

**Purpose**: Player-specific features — camera, input handling, equipment, HUD data

```cpp
UCLASS()
class HATTIN_API AHattinPlayerCharacter : public AHattinCharacterBase
{
    GENERATED_BODY()
    
public:
    AHattinPlayerCharacter();
    
    // Getters for components
    FORCEINLINE USpringArmComponent* GetCameraBoom() const { return CameraBoom; }
    FORCEINLINE UCameraComponent* GetFollowCamera() const { return FollowCamera; }
    FORCEINLINE UHattinEquipmentComponent* GetEquipmentComponent() const { return EquipmentComponent; }
    FORCEINLINE UHattinInputBufferComponent* GetInputBufferComponent() const { return InputBufferComponent; }
    
protected:
    // Camera components
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Camera")
    TObjectPtr<USpringArmComponent> CameraBoom;
    
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Camera")
    TObjectPtr<UCameraComponent> FollowCamera;
    
    // Player-specific components
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Equipment")
    TObjectPtr<UHattinEquipmentComponent> EquipmentComponent;
    
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Input")
    TObjectPtr<UHattinInputBufferComponent> InputBufferComponent;
    
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Targeting")
    TObjectPtr<UHattinTargetingComponent> TargetingComponent;
    
    // Lifecycle
    virtual void PossessedBy(AController* NewController) override;
    virtual void OnRep_PlayerState() override;
    virtual void SetupPlayerInputComponent(UInputComponent* PlayerInputComponent) override;
    
private:
    // Initialize GAS from PlayerState (multiplayer-ready pattern)
    void InitializeAbilitySystem();
};
```

### 3.3 Component: UHattinCombatComponent

**UE Base**: `UActorComponent` | **Your Class**: `UHattinCombatComponent`

**Purpose**: Manages combat state, hit detection coordination, combo tracking

```cpp
UCLASS(ClassGroup=(Hattin), meta=(BlueprintSpawnableComponent))
class HATTIN_API UHattinCombatComponent : public UActorComponent
{
    GENERATED_BODY()
    
public:
    UHattinCombatComponent();
    
    // Combat State
    UPROPERTY(BlueprintReadOnly, Category = "Combat")
    EHattinCombatState CurrentState;
    
    UPROPERTY(BlueprintReadOnly, Category = "Combat")
    int32 CurrentComboIndex;
    
    UPROPERTY(BlueprintReadOnly, Category = "Combat")
    bool bIsInHitWindow;
    
    // Functions
    UFUNCTION(BlueprintCallable, Category = "Combat")
    void StartAttack(EHattinAttackType AttackType);
    
    UFUNCTION(BlueprintCallable, Category = "Combat")
    void EnableHitWindow();
    
    UFUNCTION(BlueprintCallable, Category = "Combat")
    void DisableHitWindow();
    
    UFUNCTION(BlueprintCallable, Category = "Combat")
    void ResetCombo();
    
    // Called by AnimNotify
    void OnHitWindowStart();
    void OnHitWindowEnd();
    void OnComboWindowStart();
    void OnComboWindowEnd();
    
protected:
    virtual void BeginPlay() override;
    
private:
    // Track already-hit actors this swing
    UPROPERTY()
    TSet<AActor*> HitActorsThisSwing;
    
    // Owner reference
    UPROPERTY()
    TWeakObjectPtr<AHattinCharacterBase> OwnerCharacter;
};
```

### 3.4 Component: UHattinEquipmentComponent

**UE Base**: `UActorComponent` | **Your Class**: `UHattinEquipmentComponent`

**Purpose**: Manages equipped weapon, spawns weapon actor, handles socket attachment

```cpp
UCLASS(ClassGroup=(Hattin), meta=(BlueprintSpawnableComponent))
class HATTIN_API UHattinEquipmentComponent : public UActorComponent
{
    GENERATED_BODY()
    
public:
    UHattinEquipmentComponent();
    
    UPROPERTY(BlueprintReadOnly, Category = "Equipment")
    TObjectPtr<AHattinWeaponActor> CurrentWeapon;
    
    UPROPERTY(BlueprintReadOnly, Category = "Equipment")
    TObjectPtr<UHattinWeaponDataAsset> CurrentWeaponData;
    
    UFUNCTION(BlueprintCallable, Category = "Equipment")
    void EquipWeapon(UHattinWeaponDataAsset* WeaponData);
    
    UFUNCTION(BlueprintCallable, Category = "Equipment")
    void UnequipWeapon();
    
    // Delegate for equipment changes
    DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnWeaponEquipped, UHattinWeaponDataAsset*, WeaponData);
    UPROPERTY(BlueprintAssignable)
    FOnWeaponEquipped OnWeaponEquipped;
    
protected:
    UPROPERTY(EditDefaultsOnly, Category = "Equipment")
    FName WeaponSocketName = TEXT("weapon_r");
    
    virtual void BeginPlay() override;
};
```

### 3.5 Constructor Pattern (CDO-Safe)

```cpp
AHattinPlayerCharacter::AHattinPlayerCharacter()
{
    // Set tick settings
    PrimaryActorTick.bCanEverTick = true;
    PrimaryActorTick.bStartWithTickEnabled = false; // Enable only when needed
    
    // Configure capsule (inherited)
    GetCapsuleComponent()->InitCapsuleSize(42.f, 96.0f);
    
    // Configure CharacterMovement for combat
    GetCharacterMovement()->bOrientRotationToMovement = false; // We use controller rotation
    GetCharacterMovement()->RotationRate = FRotator(0.0f, 500.0f, 0.0f);
    GetCharacterMovement()->MaxWalkSpeed = 500.f;
    GetCharacterMovement()->BrakingDecelerationWalking = 2000.f;
    
    // Don't rotate character to camera
    bUseControllerRotationPitch = false;
    bUseControllerRotationYaw = true; // Face where we look in combat
    bUseControllerRotationRoll = false;
    
    // Create camera boom
    CameraBoom = CreateDefaultSubobject<USpringArmComponent>(TEXT("CameraBoom"));
    CameraBoom->SetupAttachment(RootComponent);
    CameraBoom->TargetArmLength = 300.0f;
    CameraBoom->bUsePawnControlRotation = true;
    CameraBoom->SocketOffset = FVector(0.f, 50.f, 60.f);
    
    // Create follow camera
    FollowCamera = CreateDefaultSubobject<UCameraComponent>(TEXT("FollowCamera"));
    FollowCamera->SetupAttachment(CameraBoom, USpringArmComponent::SocketName);
    FollowCamera->bUsePawnControlRotation = false;
    
    // Create gameplay components (UActorComponent - no attachment needed)
    CombatComponent = CreateDefaultSubobject<UHattinCombatComponent>(TEXT("CombatComponent"));
    EquipmentComponent = CreateDefaultSubobject<UHattinEquipmentComponent>(TEXT("EquipmentComponent"));
    InputBufferComponent = CreateDefaultSubobject<UHattinInputBufferComponent>(TEXT("InputBufferComponent"));
    TargetingComponent = CreateDefaultSubobject<UHattinTargetingComponent>(TEXT("TargetingComponent"));
    
    // Note: ASC created here only if NOT using PlayerState pattern
    // For multiplayer-ready setup, ASC lives on PlayerState
}
```

---

## 4. External Interfaces

### Inputs From Other Systems

| Source System | What It Provides | Interface Point |
|--------------|------------------|-----------------|
| Enhanced Input | Movement vectors, action triggers | `SetupPlayerInputComponent()` |
| GAS | Ability activation, attribute changes | `IAbilitySystemInterface` |
| Animation System | Montage events (hit windows, combos) | `AnimNotify` → CombatComponent |
| AI Perception | Detection stimulus | `UAIPerceptionStimuliSourceComponent` |

### Outputs To Other Systems

| Target System | What This Provides | Interface Point |
|--------------|---------------------|-----------------|
| Camera System | Root transform, target focus | CameraBoom attachment |
| Combat System | Combat state, hit window status | CombatComponent getters |
| GAS | Avatar actor for abilities | `InitAbilityActorInfo()` |
| UI/HUD | Health, stamina, equipment state | Attribute delegates, Equipment delegates |

---

## 5. Data Flow Diagram

```mermaid
flowchart LR
    subgraph Input
        Controller["PlayerController"]
        EnhancedInput["Enhanced Input"]
    end
    
    subgraph Character["AHattinPlayerCharacter"]
        InputBuffer["Input Buffer"]
        Combat["Combat Component"]
        Equipment["Equipment Component"]
        CMC["Movement Component"]
    end
    
    subgraph Output
        GAS["Ability System"]
        Animation["Animation BP"]
        Weapon["Weapon Actor"]
    end
    
    Controller -->|"Possess"| Character
    EnhancedInput -->|"IA_Attack, IA_Dodge..."| InputBuffer
    InputBuffer -->|"Buffered Action"| Combat
    Combat -->|"TryActivateAbility"| GAS
    GAS -->|"Play Montage"| Animation
    Equipment -->|"Spawn/Attach"| Weapon
    Combat -->|"Combat State"| Animation
    CMC -->|"Velocity, Grounded"| Animation
    
    style Controller fill:#2d3748,stroke:#4a5568,color:#a0aec0
    style EnhancedInput fill:#2d3748,stroke:#4a5568,color:#a0aec0
    style InputBuffer fill:#22543d,stroke:#276749,color:#fff
    style Combat fill:#22543d,stroke:#276749,color:#fff
    style Equipment fill:#22543d,stroke:#276749,color:#fff
    style CMC fill:#1a365d,stroke:#2c5282,color:#fff
    style GAS fill:#44337a,stroke:#553c9a,color:#fff
    style Animation fill:#2d3748,stroke:#4a5568,color:#a0aec0
    style Weapon fill:#2d3748,stroke:#4a5568,color:#a0aec0
```

---

## 6. Implementation Patterns

### Pattern: Component-First Composition

**Problem**: Character classes become bloated with unrelated functionality (combat, equipment, targeting, etc.)

**Solution**: Extract distinct functionality into `UActorComponent` subclasses. The Character becomes a thin shell that creates and coordinates components.

**Your Application**: 
- `UHattinCombatComponent` handles all combat state and hit detection
- `UHattinEquipmentComponent` manages weapon spawning and attachment
- `UHattinInputBufferComponent` handles input buffering for combos

```cpp
// Character is thin - delegates to components
void AHattinPlayerCharacter::StartAttack(EHattinAttackType Type)
{
    // Check buffer first
    if (InputBufferComponent->HasBufferedInput(Type))
    {
        CombatComponent->StartAttack(Type);
    }
}
```

### Pattern: Interface Segregation (IAbilitySystemInterface)

**Problem**: Need polymorphic access to ASC without knowing concrete character class

**Solution**: Implement `IAbilitySystemInterface` on all GAS-using actors. External systems call `GetAbilitySystemComponent()` without caring about class hierarchy.

**Your Application**: Both `AHattinPlayerCharacter` and `AHattinEnemyCharacter` implement the interface, allowing combat systems to interact with either uniformly.

```cpp
// In damage calculation - works for any character type
if (IAbilitySystemInterface* Target = Cast<IAbilitySystemInterface>(HitActor))
{
    if (UAbilitySystemComponent* TargetASC = Target->GetAbilitySystemComponent())
    {
        TargetASC->ApplyGameplayEffectToSelf(DamageEffect, 1.0f, Context);
    }
}
```

### Pattern: ASC on PlayerState (Multiplayer-Ready)

**Problem**: When player character dies and respawns, you lose ability cooldowns, buffs, and attribute state

**Solution**: Place `AbilitySystemComponent` on `PlayerState` (persists across respawns). Character becomes the "Avatar" that executes abilities but doesn't own them.

**Your Application**: `AHattinPlayerState` owns the ASC. On possession, `InitAbilityActorInfo(PlayerState, Character)` links them.

```cpp
void AHattinPlayerCharacter::PossessedBy(AController* NewController)
{
    Super::PossessedBy(NewController);
    
    if (AHattinPlayerState* PS = GetPlayerState<AHattinPlayerState>())
    {
        AbilitySystemComponent = PS->GetAbilitySystemComponent();
        AbilitySystemComponent->InitAbilityActorInfo(PS, this); // PS = Owner, this = Avatar
        
        // Get the AttributeSet from PlayerState too
        AttributeSet = PS->GetAttributeSet();
    }
}
```

### Pattern: Cached Component References

**Problem**: `GetComponentByClass()` and `FindComponentByClass()` have overhead when called frequently

**Solution**: Cache component references in `PostInitializeComponents()` when all components are guaranteed to exist

**Your Application**: Cache `AnimInstance`, sibling components, and any frequently-accessed references.

```cpp
void AHattinCharacterBase::PostInitializeComponents()
{
    Super::PostInitializeComponents();
    
    // Cache AnimInstance - used every frame for state checks
    if (GetMesh())
    {
        AnimInstance = Cast<UHattinAnimInstance>(GetMesh()->GetAnimInstance());
    }
}
```

### Anti-Patterns to Avoid

| Anti-Pattern | Problem | Solution |
|-------------|---------|----------|
| **Monolithic Character Class** | 5000+ line Character.cpp with combat, inventory, dialogue, etc. | Extract into components |
| **Tick-Heavy Updates** | Checking combat state every frame in Character::Tick | Use events/delegates, AnimNotifies |
| **Hard References to Player** | Enemy code casts directly to `AHattinPlayerCharacter` | Use interfaces: `ICombatTarget`, `IAbilitySystemInterface` |
| **Gameplay Logic in Constructor** | Spawning actors, accessing World in constructor | Move to `BeginPlay()` or `PossessedBy()` |
| **Forgetting `Super::` Calls** | Override `BeginPlay()` without calling `Super::BeginPlay()` | Always call Super for lifecycle methods |

---

## 7. Quick Reference Card

| Concept | UE5 Class | Hattin Class | File Location |
|---------|-----------|--------------|---------------|
| Base Character | `ACharacter` | `AHattinCharacterBase` | `/Source/Hattin/Character/` |
| Player Character | `ACharacter` | `AHattinPlayerCharacter` | `/Source/Hattin/Character/` |
| Enemy Character | `ACharacter` | `AHattinEnemyCharacter` | `/Source/Hattin/Character/` |
| Combat Component | `UActorComponent` | `UHattinCombatComponent` | `/Source/Hattin/Combat/` |
| Equipment Component | `UActorComponent` | `UHattinEquipmentComponent` | `/Source/Hattin/Equipment/` |
| Input Buffer | `UActorComponent` | `UHattinInputBufferComponent` | `/Source/Hattin/Input/` |
| Targeting Component | `UActorComponent` | `UHattinTargetingComponent` | `/Source/Hattin/Camera/` |
| Player Blueprint | — | `BP_HattinPlayerCharacter` | `/Content/Hattin/Blueprints/Character/` |

---

## 8. Connections Map (Compact)

```mermaid
flowchart TD
    subgraph CHARACTER_SYSTEM["Player Character System"]
        Base["AHattinCharacterBase"]
        Player["AHattinPlayerCharacter"]
        Combat["CombatComponent"]
        Equip["EquipmentComponent"]
    end
    
    INPUT[Enhanced Input] -.->|"actions"| Player
    Player -.->|"possesses"| GAS[Gameplay Ability System]
    Combat -.->|"activates abilities"| GAS
    Combat -.->|"hit events"| COLLISION[Combat Collision]
    Equip -.->|"weapon data"| DATA[Data-Driven Design]
    Player -.->|"state variables"| ANIM[Animation System]
    Player -.->|"camera target"| CAMERA[Camera System]
    
    style CHARACTER_SYSTEM fill:#22543d,stroke:#276749
    style INPUT fill:#2d3748,stroke:#4a5568,color:#a0aec0
    style GAS fill:#2d3748,stroke:#4a5568,color:#a0aec0
    style COLLISION fill:#2d3748,stroke:#4a5568,color:#a0aec0
    style DATA fill:#2d3748,stroke:#4a5568,color:#a0aec0
    style ANIM fill:#2d3748,stroke:#4a5568,color:#a0aec0
    style CAMERA fill:#2d3748,stroke:#4a5568,color:#a0aec0
```

---

## Summary

The Player Character Architecture establishes:

1. **Inheritance**: `UObject` → `AActor` → `APawn` → `ACharacter` → `AHattinCharacterBase` → `AHattinPlayerCharacter`

2. **Composition**: Character is a thin coordinator; functionality lives in components (`CombatComponent`, `EquipmentComponent`, `InputBufferComponent`)

3. **GAS Integration**: ASC on PlayerState for persistence, Character as Avatar for execution

4. **Lifecycle Awareness**: Components created in Constructor, configured in `PostInitializeComponents`, gameplay in `BeginPlay`

5. **Interface Segregation**: `IAbilitySystemInterface` allows uniform interaction regardless of character type

This architecture supports clean separation of concerns, multiplayer readiness, and the combat-focused gameplay Hattin requires.
