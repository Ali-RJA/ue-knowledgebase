# Game Framework Architecture
> The backbone classes that orchestrate gameplay — GameMode for rules,
> GameState for shared state, PlayerController for input, PlayerState for
> player data, and GameInstance for persistence.

---

## 1. System Overview

The Game Framework solves the problem of organizing game-wide logic: who controls spawning, where player data lives, what persists between levels, and how state is replicated in multiplayer. UE5 provides a hierarchy of framework classes, each with distinct responsibilities.

Understanding framework ownership is critical: GameMode exists only on the server and controls rules. GameState replicates to all clients and holds match state. PlayerState replicates and holds per-player data. PlayerController is the bridge between player and pawn. GameInstance persists across level transitions.

For Hattin specifically, even as a single-player focused game, using the full framework provides: clean separation of concerns, future multiplayer readiness, proper save/load architecture, and match phase management.

---

## 2. Core Architecture Diagram

### 2.1 Framework Class Relationships

```mermaid
flowchart TD
    subgraph "Server Only"
        GM["AHattinGameMode<br/>(Rules, Spawning)"]
    end
    
    subgraph "Replicated to All"
        GS["AHattinGameState<br/>(Match Phase, Score)"]
        PS["AHattinPlayerState<br/>(Player Data, Stats)"]
        Pawn["AHattinPlayerCharacter<br/>(Physical Presence)"]
    end
    
    subgraph "Server + Owning Client"
        PC["AHattinPlayerController<br/>(Input, HUD)"]
    end
    
    subgraph "Local Only (Persistent)"
        GI["UHattinGameInstance<br/>(Save Data, Settings)"]
    end
    
    GM -->|"spawns"| PC
    GM -->|"spawns"| Pawn
    GM -->|"creates"| GS
    PC -->|"possesses"| Pawn
    PC -->|"creates"| PS
    GI -->|"persists across"| Levels["Level Transitions"]
    
    style GM fill:#742a2a,stroke:#9b2c2c,color:#fff
    style GS fill:#44337a,stroke:#553c9a,color:#fff
    style PS fill:#44337a,stroke:#553c9a,color:#fff
    style PC fill:#22543d,stroke:#276749,color:#fff
    style GI fill:#0d4f4f,stroke:#0f5e5e,color:#fff
```

### 2.2 Spawning Chain

```mermaid
sequenceDiagram
    participant World as World
    participant GM as GameMode
    participant PC as PlayerController
    participant PS as PlayerState
    participant Pawn as Character
    
    Note over World,Pawn: Player Joins
    World->>GM: InitGame()
    World->>GM: Login()
    GM->>PC: SpawnPlayerController()
    PC->>PS: CreatePlayerState()
    
    Note over World,Pawn: Spawn Pawn
    GM->>GM: HandleStartingNewPlayer()
    GM->>GM: FindPlayerStart()
    GM->>Pawn: SpawnDefaultPawnFor()
    GM->>PC: Possess(Pawn)
    
    Note over World,Pawn: Initialize Systems
    Pawn->>Pawn: PossessedBy()
    Pawn->>PS: GetAbilitySystemComponent()
    Pawn->>Pawn: InitAbilityActorInfo()
```

### 2.3 Data Ownership

```mermaid
flowchart LR
    subgraph "Match Data (GameState)"
        MatchPhase["MatchPhase"]
        EnemiesRemaining["EnemiesRemaining"]
        MatchTime["MatchTimeElapsed"]
    end
    
    subgraph "Player Data (PlayerState)"
        EnemiesDefeated["EnemiesDefeated"]
        Deaths["Deaths"]
        CurrentScore["CurrentScore"]
    end
    
    subgraph "Persistent Data (GameInstance)"
        SaveData["CurrentSaveData"]
        Settings["GameSettings"]
        UnlockedItems["UnlockedItems"]
    end
    
    subgraph "Transient Data (Pawn)"
        Health["Current Health"]
        Position["Position"]
        CombatState["Combat State"]
    end
    
    style MatchPhase fill:#44337a,stroke:#553c9a,color:#fff
    style EnemiesDefeated fill:#22543d,stroke:#276749,color:#fff
    style SaveData fill:#0d4f4f,stroke:#0f5e5e,color:#fff
    style Health fill:#b7791f,stroke:#d69e2e,color:#000
```

---

## 3. Component Specifications

### 3.1 AHattinGameMode

**UE Base**: `AGameModeBase` | **Your Class**: `AHattinGameMode`

```cpp
UCLASS()
class HATTIN_API AHattinGameMode : public AGameModeBase
{
    GENERATED_BODY()
    
public:
    AHattinGameMode();
    
    virtual void InitGame(const FString& MapName, const FString& Options, FString& ErrorMessage) override;
    virtual APawn* SpawnDefaultPawnFor_Implementation(AController* NewPlayer, AActor* StartSpot) override;
    virtual void HandleStartingNewPlayer_Implementation(APlayerController* NewPlayer) override;
    
    UFUNCTION(BlueprintCallable, Category = "Game")
    void OnEnemyDefeated(AHattinEnemyCharacter* Enemy, AController* Killer);
    
    UFUNCTION(BlueprintCallable, Category = "Game")
    void OnPlayerDeath(AHattinPlayerCharacter* Player);
    
    UFUNCTION(BlueprintCallable, Category = "Game")
    void RespawnPlayer(AController* Controller);
    
protected:
    UPROPERTY(EditDefaultsOnly, Category = "Classes")
    TSubclassOf<AHattinPlayerCharacter> PlayerCharacterClass;
    
    UPROPERTY(EditDefaultsOnly, Category = "Classes")
    TSubclassOf<AHattinPlayerController> PlayerControllerClass;
    
    UPROPERTY(EditDefaultsOnly, Category = "Classes")
    TSubclassOf<AHattinPlayerState> PlayerStateClass;
    
    UPROPERTY(EditDefaultsOnly, Category = "Spawning")
    float RespawnDelay = 3.0f;
};
```

### 3.2 AHattinGameState

**UE Base**: `AGameStateBase` | **Your Class**: `AHattinGameState`

```cpp
UCLASS()
class HATTIN_API AHattinGameState : public AGameStateBase
{
    GENERATED_BODY()
    
public:
    AHattinGameState();
    
    virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;
    
    UPROPERTY(ReplicatedUsing=OnRep_MatchPhase, BlueprintReadOnly, Category = "Match")
    EHattinMatchPhase MatchPhase;
    
    UPROPERTY(Replicated, BlueprintReadOnly, Category = "Match")
    int32 EnemiesRemaining;
    
    UPROPERTY(Replicated, BlueprintReadOnly, Category = "Match")
    float MatchTimeElapsed;
    
    UFUNCTION(BlueprintCallable, Category = "Match")
    void SetMatchPhase(EHattinMatchPhase NewPhase);
    
    DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnMatchPhaseChanged, EHattinMatchPhase, NewPhase);
    UPROPERTY(BlueprintAssignable)
    FOnMatchPhaseChanged OnMatchPhaseChanged;
    
protected:
    UFUNCTION()
    void OnRep_MatchPhase();
};
```

### 3.3 AHattinPlayerState

**UE Base**: `APlayerState` | **Your Class**: `AHattinPlayerState`

```cpp
UCLASS()
class HATTIN_API AHattinPlayerState : public APlayerState
{
    GENERATED_BODY()
    
public:
    AHattinPlayerState();
    
    virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;
    
    // ASC lives here for persistence across respawns
    virtual UAbilitySystemComponent* GetAbilitySystemComponent() const;
    UHattinAttributeSet* GetAttributeSet() const { return AttributeSet; }
    
    UPROPERTY(Replicated, BlueprintReadOnly, Category = "Stats")
    int32 EnemiesDefeated;
    
    UPROPERTY(Replicated, BlueprintReadOnly, Category = "Stats")
    int32 Deaths;
    
    UFUNCTION(BlueprintCallable, Category = "Stats")
    void AddEnemyDefeated();
    
    UFUNCTION(BlueprintCallable, Category = "Stats")
    void AddDeath();
    
protected:
    UPROPERTY(VisibleAnywhere, Category = "GAS")
    TObjectPtr<UAbilitySystemComponent> AbilitySystemComponent;
    
    UPROPERTY()
    TObjectPtr<UHattinAttributeSet> AttributeSet;
};
```

### 3.4 UHattinGameInstance

**UE Base**: `UGameInstance` | **Your Class**: `UHattinGameInstance`

```cpp
UCLASS()
class HATTIN_API UHattinGameInstance : public UGameInstance
{
    GENERATED_BODY()
    
public:
    virtual void Init() override;
    
    // Save/Load
    UFUNCTION(BlueprintCallable, Category = "Save")
    void SaveGame();
    
    UFUNCTION(BlueprintCallable, Category = "Save")
    void LoadGame(int32 SlotIndex);
    
    UFUNCTION(BlueprintCallable, Category = "Save")
    bool HasSaveGame(int32 SlotIndex) const;
    
    // Current save data (persists across levels)
    UPROPERTY(BlueprintReadOnly, Category = "Save")
    FHattinSaveData CurrentSaveData;
    
    // Game settings
    UPROPERTY(BlueprintReadWrite, Category = "Settings")
    FHattinGameSettings GameSettings;
    
protected:
    UPROPERTY()
    TObjectPtr<UHattinSaveSubsystem> SaveSubsystem;
};
```

---

## 4. External Interfaces

### Inputs From Other Systems

| Source System | What It Provides | Interface Point |
|--------------|------------------|-----------------|
| Level Blueprint | Match triggers | GameMode events |
| Player Input | Join request | GameMode::Login |
| Enemy AI | Death notification | GameMode::OnEnemyDefeated |

### Outputs To Other Systems

| Target System | What This Provides | Interface Point |
|--------------|---------------------|-----------------|
| GAS | ASC from PlayerState | `IAbilitySystemInterface` |
| UI | Match state, player stats | GameState/PlayerState queries |
| Save System | Persistent data | GameInstance save data |

---

## 5. Implementation Patterns

### Pattern: ASC on PlayerState

**Problem**: Character dies and respawns, losing ability state

**Solution**: ASC lives on PlayerState, persists across respawns

```cpp
void AHattinPlayerCharacter::PossessedBy(AController* NewController)
{
    Super::PossessedBy(NewController);
    
    if (AHattinPlayerState* PS = GetPlayerState<AHattinPlayerState>())
    {
        // Get ASC from PlayerState (not character)
        AbilitySystemComponent = PS->GetAbilitySystemComponent();
        AbilitySystemComponent->InitAbilityActorInfo(PS, this);
    }
}
```

### Pattern: GameMode as Authority

**Problem**: Multiple systems try to manage spawning

**Solution**: GameMode is single source of truth for game rules

```cpp
void AHattinGameMode::OnPlayerDeath(AHattinPlayerCharacter* Player)
{
    // GameMode decides what happens
    if (AHattinGameState* GS = GetGameState<AHattinGameState>())
    {
        if (GS->MatchPhase == EHattinMatchPhase::InProgress)
        {
            // Schedule respawn
            FTimerHandle RespawnHandle;
            GetWorldTimerManager().SetTimer(RespawnHandle, [this, Player]()
            {
                RespawnPlayer(Player->GetController());
            }, RespawnDelay, false);
        }
    }
}
```

---

## 6. Quick Reference Card

| Class | Network Scope | Responsibility | Location |
|-------|--------------|----------------|----------|
| `AHattinGameMode` | Server Only | Rules, spawning | `/Source/Hattin/Framework/` |
| `AHattinGameState` | All Clients | Match state | `/Source/Hattin/Framework/` |
| `AHattinPlayerState` | All Clients | Player stats, ASC | `/Source/Hattin/Framework/` |
| `AHattinPlayerController` | Owning Client | Input, HUD | `/Source/Hattin/Framework/` |
| `UHattinGameInstance` | Local Only | Save, settings | `/Source/Hattin/Framework/` |

---

## 7. Connections Map (Compact)

```mermaid
flowchart TD
    subgraph FRAMEWORK["Game Framework"]
        GM["GameMode (Server)"]
        GS["GameState (Replicated)"]
        PS["PlayerState (Replicated)"]
        GI["GameInstance (Local)"]
    end
    
    GM -.->|"spawns"| CHAR[Player Character]
    GS -.->|"match data"| UI[UI System]
    PS -.->|"owns ASC"| GAS[Gameplay Ability System]
    GI -.->|"save/load"| SAVE[Save System]
    
    style FRAMEWORK fill:#742a2a,stroke:#9b2c2c
    style CHAR fill:#2d3748,stroke:#4a5568,color:#a0aec0
    style UI fill:#2d3748,stroke:#4a5568,color:#a0aec0
    style GAS fill:#2d3748,stroke:#4a5568,color:#a0aec0
    style SAVE fill:#2d3748,stroke:#4a5568,color:#a0aec0
```

---

## Summary

The Game Framework architecture establishes:

1. **GameMode (Server)**: Rules authority, spawning, match flow
2. **GameState (Replicated)**: Match phase, enemy count, timer
3. **PlayerState (Replicated)**: Per-player stats, ASC ownership
4. **PlayerController**: Input handling, HUD management
5. **GameInstance (Local)**: Persistent data across levels, save system

This separation ensures clean architecture and future multiplayer readiness.
