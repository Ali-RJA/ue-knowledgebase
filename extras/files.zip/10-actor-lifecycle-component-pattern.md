# Actor Lifecycle & Component Pattern Architecture
> The foundational patterns of UE5 object creation — understanding when
> constructors run, when components initialize, and how to safely access
> game systems at each lifecycle stage.

---

## 1. System Overview

Actor Lifecycle management solves the problem of knowing when it's safe to access the World, other Actors, and game systems. UE5 has a specific initialization order, and putting code in the wrong lifecycle method causes crashes, null pointers, or undefined behavior.

The Component Pattern solves the problem of reusability and composition. Rather than deep inheritance hierarchies, functionality is composed from modular components that can be mixed and matched across different Actor types.

For Hattin specifically, understanding lifecycle is critical for: initializing GAS correctly, caching component references safely, spawning actors at runtime, and implementing object pooling for performance.

---

## 2. Core Architecture Diagram

### 2.1 Actor Lifecycle Flow

```mermaid
flowchart TD
    subgraph "Construction Phase"
        CDO["CDO Creation<br/>(Class Default Object)"]
        Constructor["Constructor<br/>CreateDefaultSubobject()"]
    end
    
    subgraph "Initialization Phase"
        PostActorCreated["PostActorCreated()<br/>(spawned actors only)"]
        OnConstruction["OnConstruction()<br/>(Blueprint construction)"]
        PreInit["PreInitializeComponents()"]
        InitComps["InitializeComponent()<br/>(each component)"]
        PostInit["PostInitializeComponents()<br/>(components ready)"]
    end
    
    subgraph "Gameplay Phase"
        BeginPlay["BeginPlay()<br/>(world ready)"]
        Tick["Tick()<br/>(per frame)"]
    end
    
    subgraph "Destruction Phase"
        EndPlay["EndPlay()<br/>(leaving world)"]
        BeginDestroy["BeginDestroy()"]
        GC["Garbage Collection"]
    end
    
    CDO --> Constructor --> PostActorCreated --> OnConstruction
    OnConstruction --> PreInit --> InitComps --> PostInit --> BeginPlay
    BeginPlay --> Tick --> EndPlay --> BeginDestroy --> GC
    
    style Constructor fill:#744210,stroke:#975a16,color:#fff
    style PostInit fill:#b7791f,stroke:#d69e2e,color:#000
    style BeginPlay fill:#22543d,stroke:#276749,color:#fff
    style EndPlay fill:#742a2a,stroke:#9b2c2c,color:#fff
```

### 2.2 Safe Operations by Lifecycle Stage

```mermaid
flowchart LR
    subgraph "Constructor"
        C_Safe["✓ CreateDefaultSubobject<br/>✓ Set default values<br/>✓ Configure component properties"]
        C_Unsafe["✗ Access World<br/>✗ Spawn actors<br/>✗ Access other actors<br/>✗ Gameplay logic"]
    end
    
    subgraph "PostInitializeComponents"
        P_Safe["✓ Cache component refs<br/>✓ Bind delegates<br/>✓ Configure components"]
        P_Unsafe["✗ Spawn actors<br/>✗ Heavy gameplay logic"]
    end
    
    subgraph "BeginPlay"
        B_Safe["✓ Start gameplay<br/>✓ Spawn actors<br/>✓ Access World<br/>✓ Find other actors"]
        B_Unsafe["✗ Create components<br/>(too late)"]
    end
    
    style C_Safe fill:#22543d,stroke:#276749,color:#fff
    style C_Unsafe fill:#742a2a,stroke:#9b2c2c,color:#fff
    style P_Safe fill:#22543d,stroke:#276749,color:#fff
    style P_Unsafe fill:#742a2a,stroke:#9b2c2c,color:#fff
    style B_Safe fill:#22543d,stroke:#276749,color:#fff
    style B_Unsafe fill:#742a2a,stroke:#9b2c2c,color:#fff
```

### 2.3 Component Hierarchy

```mermaid
flowchart TD
    subgraph "UE5 Component Hierarchy"
        UObject["UObject"]
        ActorComp["UActorComponent<br/>(no transform)"]
        SceneComp["USceneComponent<br/>(has transform)"]
        PrimComp["UPrimitiveComponent<br/>(rendering/collision)"]
    end
    
    subgraph "Derived Components"
        StaticMesh["UStaticMeshComponent"]
        SkelMesh["USkeletalMeshComponent"]
        Capsule["UCapsuleComponent"]
        SpringArm["USpringArmComponent"]
        Camera["UCameraComponent"]
    end
    
    subgraph "Custom Components"
        Combat["UHattinCombatComponent<br/>(UActorComponent)"]
        Equipment["UHattinEquipmentComponent<br/>(UActorComponent)"]
        Targeting["UHattinTargetingComponent<br/>(UActorComponent)"]
    end
    
    UObject --> ActorComp --> SceneComp --> PrimComp
    PrimComp --> StaticMesh
    PrimComp --> SkelMesh
    PrimComp --> Capsule
    SceneComp --> SpringArm
    SceneComp --> Camera
    ActorComp --> Combat
    ActorComp --> Equipment
    ActorComp --> Targeting
    
    style ActorComp fill:#0d4f4f,stroke:#0f5e5e,color:#fff
    style SceneComp fill:#44337a,stroke:#553c9a,color:#fff
    style PrimComp fill:#1a365d,stroke:#2c5282,color:#fff
    style Combat fill:#22543d,stroke:#276749,color:#fff
```

---

## 3. Component Specifications

### 3.1 Component Type Decision Guide

| Need | Component Type | Example |
|------|---------------|---------|
| Pure logic, no position | `UActorComponent` | Combat, Inventory, Stats |
| Needs position, no visuals | `USceneComponent` | Attachment points, targets |
| Visuals or collision | `UPrimitiveComponent` subclass | Mesh, capsule, box |

### 3.2 Constructor Pattern

```cpp
AHattinPlayerCharacter::AHattinPlayerCharacter()
{
    // Set tick BEFORE creating components
    PrimaryActorTick.bCanEverTick = true;
    PrimaryActorTick.bStartWithTickEnabled = false;
    
    // Configure inherited components
    GetCapsuleComponent()->InitCapsuleSize(42.f, 96.0f);
    GetCharacterMovement()->MaxWalkSpeed = 500.f;
    
    // Create scene components (need attachment)
    CameraBoom = CreateDefaultSubobject<USpringArmComponent>(TEXT("CameraBoom"));
    CameraBoom->SetupAttachment(RootComponent);
    CameraBoom->TargetArmLength = 300.0f;
    
    FollowCamera = CreateDefaultSubobject<UCameraComponent>(TEXT("FollowCamera"));
    FollowCamera->SetupAttachment(CameraBoom, USpringArmComponent::SocketName);
    
    // Create actor components (no attachment)
    CombatComponent = CreateDefaultSubobject<UHattinCombatComponent>(TEXT("CombatComponent"));
    EquipmentComponent = CreateDefaultSubobject<UHattinEquipmentComponent>(TEXT("EquipmentComponent"));
    
    // NEVER do this in constructor:
    // - GetWorld() → nullptr
    // - SpawnActor() → crash
    // - FindComponentByClass on other actors → crash
}
```

### 3.3 PostInitializeComponents Pattern

```cpp
void AHattinCharacterBase::PostInitializeComponents()
{
    Super::PostInitializeComponents(); // Always call Super!
    
    // Components are now fully initialized - safe to cache refs
    if (GetMesh())
    {
        AnimInstance = Cast<UHattinAnimInstance>(GetMesh()->GetAnimInstance());
    }
    
    // Bind delegates between components
    if (CombatComponent && AnimInstance.IsValid())
    {
        CombatComponent->OnAttackStarted.AddDynamic(
            AnimInstance.Get(), &UHattinAnimInstance::OnCombatAttackStarted);
    }
}
```

### 3.4 BeginPlay Pattern

```cpp
void AHattinPlayerCharacter::BeginPlay()
{
    Super::BeginPlay(); // Always call Super!
    
    // World is now valid - safe to spawn, find actors
    if (UWorld* World = GetWorld())
    {
        // Can spawn actors now
        if (DefaultWeaponClass)
        {
            AHattinWeaponActor* Weapon = World->SpawnActor<AHattinWeaponActor>(DefaultWeaponClass);
            EquipmentComponent->EquipWeapon(Weapon);
        }
    }
    
    // Enable tick if needed
    SetActorTickEnabled(true);
}
```

### 3.5 Runtime Component Creation

```cpp
void AHattinPlayerCharacter::AddRuntimeComponent()
{
    // Runtime-created components need manual registration
    UStaticMeshComponent* NewMesh = NewObject<UStaticMeshComponent>(this);
    NewMesh->SetupAttachment(GetMesh(), TEXT("socket_name"));
    NewMesh->SetStaticMesh(SomeMesh);
    NewMesh->RegisterComponent(); // REQUIRED for runtime components
    
    // Add to instance components array for proper cleanup
    AddInstanceComponent(NewMesh);
}
```

---

## 4. Implementation Patterns

### Pattern: Deferred Spawning

**Problem**: Need to configure spawned actor before BeginPlay

**Solution**: Use SpawnActorDeferred → Configure → FinishSpawning

```cpp
void AHattinEnemySpawner::SpawnEnemy()
{
    FActorSpawnParameters Params;
    Params.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn;
    
    // Deferred spawn - actor exists but BeginPlay not called
    AHattinEnemyCharacter* Enemy = GetWorld()->SpawnActorDeferred<AHattinEnemyCharacter>(
        EnemyClass,
        SpawnTransform,
        nullptr,
        nullptr,
        ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn
    );
    
    // Configure before BeginPlay
    Enemy->SetEnemyData(EnemyDataAsset);
    Enemy->SetPatrolPath(PatrolPath);
    
    // Now finish spawning (calls BeginPlay)
    Enemy->FinishSpawning(SpawnTransform);
}
```

### Pattern: Object Pooling

**Problem**: Frequent spawn/destroy of projectiles causes hitches

**Solution**: Pool and reuse actors

```cpp
AHattinProjectile* UHattinObjectPoolSubsystem::GetProjectile()
{
    for (AHattinProjectile* Pooled : ProjectilePool)
    {
        if (!Pooled->IsActive())
        {
            Pooled->Activate();
            return Pooled;
        }
    }
    
    // Pool exhausted, spawn new
    AHattinProjectile* NewProjectile = GetWorld()->SpawnActor<AHattinProjectile>(ProjectileClass);
    ProjectilePool.Add(NewProjectile);
    return NewProjectile;
}

void AHattinProjectile::Deactivate()
{
    SetActorHiddenInGame(true);
    SetActorEnableCollision(false);
    SetActorTickEnabled(false);
    // Don't destroy - return to pool
}
```

### Pattern: Component Composition

**Problem**: Different character types need overlapping functionality

**Solution**: Extract into components, compose as needed

```cpp
// UHattinHealthComponent can be used by:
// - Player characters
// - Enemy characters  
// - Destructible props
// - Vehicles

UCLASS()
class UHattinHealthComponent : public UActorComponent
{
    // Same health logic, reusable across actor types
};
```

---

## 5. Anti-Patterns to Avoid

| Anti-Pattern | Problem | Solution |
|-------------|---------|----------|
| **World access in Constructor** | World is nullptr | Move to BeginPlay |
| **Spawning in Constructor** | Crash | Move to BeginPlay |
| **Creating components in BeginPlay** | Too late, not serialized | Create in Constructor |
| **Forgetting RegisterComponent** | Runtime components don't work | Always call RegisterComponent |
| **Heavy Tick operations** | Performance | Use timers, events |
| **Forgetting Super:: calls** | Base class logic skipped | Always call Super for lifecycle |

---

## 6. Quick Reference Card

| Lifecycle Method | Safe To Do | NOT Safe |
|-----------------|-----------|----------|
| **Constructor** | CreateDefaultSubobject, set defaults | World access, spawn, gameplay |
| **PostInitializeComponents** | Cache refs, bind delegates | Spawn actors |
| **BeginPlay** | Everything gameplay | Create components |
| **Tick** | Per-frame updates | Heavy operations |
| **EndPlay** | Cleanup, unbind | Access destroyed actors |

| Component Type | Use When |
|---------------|----------|
| `UActorComponent` | Logic only, no position needed |
| `USceneComponent` | Needs transform, attachment |
| `UPrimitiveComponent+` | Needs rendering or collision |

---

## 7. Connections Map (Compact)

```mermaid
flowchart TD
    subgraph LIFECYCLE["Actor Lifecycle"]
        Constructor["Constructor"]
        PostInit["PostInitializeComponents"]
        BeginPlay["BeginPlay"]
        EndPlay["EndPlay"]
    end
    
    Constructor -.->|"creates"| COMPS[Components]
    PostInit -.->|"caches refs"| COMPS
    BeginPlay -.->|"starts"| GAMEPLAY[Gameplay Systems]
    EndPlay -.->|"cleanup"| COMPS
    
    style LIFECYCLE fill:#744210,stroke:#975a16
    style COMPS fill:#2d3748,stroke:#4a5568,color:#a0aec0
    style GAMEPLAY fill:#2d3748,stroke:#4a5568,color:#a0aec0
```

---

## Summary

The Actor Lifecycle & Component Pattern architecture establishes:

1. **Constructor**: CreateDefaultSubobject only, set defaults, NO world access
2. **PostInitializeComponents**: Cache references, bind delegates, components ready
3. **BeginPlay**: Start gameplay, spawn actors, world is valid
4. **EndPlay**: Cleanup, unbind, save state
5. **Component Types**: ActorComponent (logic), SceneComponent (transform), PrimitiveComponent (visuals)
6. **Runtime Components**: Must call RegisterComponent() after NewObject
7. **Deferred Spawning**: Configure actors before BeginPlay with SpawnActorDeferred

This understanding prevents null pointer crashes and ensures systems initialize in the correct order.
